minetest.register_node("details:barrel1", {
	description = "wooden barrel",
	mesh = "wooden_barrel.obj",
	tiles = {"barrel-wood.png"},
	drawtype = "mesh",
	groups = {cracky = 3, stone = 1},
	--drop = 'default:cobble',
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.25, 0.3125, 0.3125, 0.3125}, -- NodeBox1
		}
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.25, 0.4375, 0.3125, 0.4375}, -- NodeBox1
			{-0.4375, -0.5, -0.5, 0.4375, -0.125, -0.25}, -- NodeBox2
		}
	}
})

minetest.register_node("details:brick_fence", {
	description = "brick fence",
	tiles = {"default_brick.png"},
	drawtype = "nodebox",
	groups = {cracky = 3, stone = 1},
	paramtype = "light",
	paramtype2 = "facedir",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0}, -- NodeBox3
		}
	}
})

