
local MP = minetest.get_modpath("firearms").."/guns"

dofile(MP.."/m9.lua")
dofile(MP.."/m3.lua")
dofile(MP.."/m4.lua")
dofile(MP.."/awp.lua")
