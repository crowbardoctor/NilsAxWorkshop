Licenses: CC0
Version: 3

Hides players nametag when they are sneaking, or invisible if you have the invisible privilege.

Give yourself the invisible stick, to toggle your invisible on/off

/giveme i